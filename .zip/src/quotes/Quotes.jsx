import React from 'react';
import { useSelector } from 'react-redux';
const Quotes = () => {
  const jokes = useSelector((state) => state.quotes.quotes);

  console.log(jokes, 'quotes');
  return (
    <div>
      {jokes.result?.map((joke) => {
        return <div className='quoteblock' key={joke.id}>{joke.value}</div>;
      })}
    </div>
  );
};

export default Quotes;


import Jokes from './MainPage';

function App() {
  return (
  
    <div className="App">
<Jokes/>
    </div>
  );
}

export default App;

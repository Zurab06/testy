import React, { useState } from 'react';
import '../MainPage/jokes.css';
import { useDispatch } from 'react-redux';
import { useEffect } from 'react';
import { fetchQuotes } from '../features/quotes/quotesSlice';
import Quotes from '../quotes/Quotes';

const Jokes = () => {
  const [value, setValue] = useState('');

  const dispatch = useDispatch();
  useEffect(() => {
    if (value.length >= 3) {
      dispatch(fetchQuotes(value));
    }
  }, [value, dispatch]);
  return (
    <div className='container'>
      <div className='inputblock'>
        <input
          onChange={(e) => setValue(e.target.value)}
          type="text"
          placeholder="Search jokes..."
          className="input"
        />
        
      </div>
      <div className='main'><Quotes /></div>
    </div>
  );
};

export default Jokes;
